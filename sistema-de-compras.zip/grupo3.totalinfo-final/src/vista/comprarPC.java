package vista;
import conexion.Conexion;
import java.sql.*;
import java.text.SimpleDateFormat;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class comprarPC extends javax.swing.JFrame {
    Conexion cn = new Conexion();
    Connection con;
    DefaultComboBoxModel modelo1;
    DefaultComboBoxModel modelo2;
    DefaultComboBoxModel modelo3;
    DefaultComboBoxModel modelo4;
    DefaultComboBoxModel modelo5;
    DefaultComboBoxModel modelo6;
    DefaultComboBoxModel modelo7;
    DefaultTableModel model;
    Statement st;
    ResultSet rs;
    int id = 0;
    
    
    public comprarPC() {
        initComponents();
        setLocationRelativeTo(null);
        modelo1 = new DefaultComboBoxModel();
        modelo2 = new DefaultComboBoxModel();
        modelo3 = new DefaultComboBoxModel();
        modelo4 = new DefaultComboBoxModel();
        modelo5 = new DefaultComboBoxModel();
        modelo6 = new DefaultComboBoxModel();
        modelo7 = new DefaultComboBoxModel();
        listar();
        cargarlistaMicros();
        cargarlistaMothers();
        cargarlistaFuentes();
        cargarlistaRam();
        cargarlistaHdd();
        cargarlistaGabinete();
        cargarlistaCooler();
    }

    public void cargarlistaMicros(){
        Conexion con = new Conexion();
       Connection cn;
       ResultSet res;
       try {
            con.getConnection();
            String sql="SELECT idStock from stock WHERE idTipo = 2";
            PreparedStatement pre = con.getConnection().prepareCall(sql);
            res = pre.executeQuery();
            modelo1.removeAllElements();
            while(res.next()){
                 modelo1.addElement(res.getString("idStock"));
             }
           slctMicro.setModel(modelo1);
     //      con.desconectar();
         } catch (Exception e) {
             System.out.println("ERROR: failed to load HSQLDB JDBC driver.");
             e.printStackTrace();
         }
       
    }
    
    public void cargarlistaMothers(){
        Conexion con = new Conexion();
       Connection cn;
       ResultSet res;
       try {
            con.getConnection();
            String sql="SELECT idStock from stock WHERE idTipo = 1";
            PreparedStatement pre = con.getConnection().prepareCall(sql);
            res = pre.executeQuery();
            modelo2.removeAllElements();
            while(res.next()){
                 modelo2.addElement(res.getString("idStock"));
             }
           slctMother.setModel(modelo2);
     //      con.desconectar();
         } catch (Exception e) {
             System.out.println("ERROR: failed to load HSQLDB JDBC driver.");
             e.printStackTrace();
         }
       
    }
    
    public void cargarlistaFuentes(){
        Conexion con = new Conexion();
       Connection cn;
       ResultSet res;
       try {
            con.getConnection();
            String sql="SELECT idStock from stock WHERE idTipo = 8";
            PreparedStatement pre = con.getConnection().prepareCall(sql);
            res = pre.executeQuery();
            modelo3.removeAllElements();
            while(res.next()){
                 modelo3.addElement(res.getString("idStock"));
             }
           slctFuente.setModel(modelo3);
     //      con.desconectar();
         } catch (Exception e) {
             System.out.println("ERROR: failed to load HSQLDB JDBC driver.");
             e.printStackTrace();
         }
       
    }
    
    public void cargarlistaRam(){
        Conexion con = new Conexion();
       Connection cn;
       ResultSet res;
       try {
            con.getConnection();
            String sql="SELECT idStock from stock WHERE idTipo = 4";
            PreparedStatement pre = con.getConnection().prepareCall(sql);
            res = pre.executeQuery();
            modelo4.removeAllElements();
            while(res.next()){
                 modelo4.addElement(res.getString("idStock"));
             }
           slctRam.setModel(modelo4);
     //      con.desconectar();
         } catch (Exception e) {
             System.out.println("ERROR: failed to load HSQLDB JDBC driver.");
             e.printStackTrace();
         }
       
    }
    public void cargarlistaHdd(){
        Conexion con = new Conexion();
       Connection cn;
       ResultSet res;
       try {
            con.getConnection();
            String sql="SELECT idStock from stock WHERE idTipo = 5 OR idTipo = 6";
            PreparedStatement pre = con.getConnection().prepareCall(sql);
            res = pre.executeQuery();
            modelo5.removeAllElements();
            while(res.next()){
                 modelo5.addElement(res.getString("idStock"));
             }
           slctHdd.setModel(modelo5);
     //      con.desconectar();
         } catch (Exception e) {
             System.out.println("ERROR: failed to load HSQLDB JDBC driver.");
             e.printStackTrace();
         }
       
    }
    public void cargarlistaGabinete(){
        Conexion con = new Conexion();
       Connection cn;
       ResultSet res;
       try {
            con.getConnection();
            String sql="SELECT idStock from stock WHERE idTipo = 3";
            PreparedStatement pre = con.getConnection().prepareCall(sql);
            res = pre.executeQuery();
            modelo6.removeAllElements();
            while(res.next()){
                 modelo6.addElement(res.getString("idStock"));
             }
           slctGab.setModel(modelo6);
     //      con.desconectar();
         } catch (Exception e) {
             System.out.println("ERROR: failed to load HSQLDB JDBC driver.");
             e.printStackTrace();
         }
       
    }
    public void cargarlistaCooler(){
        Conexion con = new Conexion();
       Connection cn;
       ResultSet res;
       try {
            con.getConnection();
            String sql="SELECT idStock from stock WHERE idTipo = 7";
            PreparedStatement pre = con.getConnection().prepareCall(sql);
            res = pre.executeQuery();
            modelo7.removeAllElements();
            while(res.next()){
                 modelo7.addElement(res.getString("idStock"));
             }
           slctCooler.setModel(modelo7);
     //      con.desconectar();
         } catch (Exception e) {
             System.out.println("ERROR: failed to load HSQLDB JDBC driver.");
             e.printStackTrace();
         }
       
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        slctMicro = new javax.swing.JComboBox<>();
        slctMother = new javax.swing.JComboBox<>();
        slctFuente = new javax.swing.JComboBox<>();
        slctRam = new javax.swing.JComboBox<>();
        slctHdd = new javax.swing.JComboBox<>();
        slctGab = new javax.swing.JComboBox<>();
        slctCooler = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaStock = new javax.swing.JTable();
        jLabel10 = new javax.swing.JLabel();
        txtPrecio = new javax.swing.JTextField();
        btnContinuar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Elegir componentes");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Microprocesador:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Motherboard:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setText("Fuente:");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("RAM:");

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("Disco duro/solido:");

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setText("Gabinete:");

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setText("Cooler:");

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setText("Precio total:");

        slctMicro.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        slctMicro.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        slctMother.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        slctMother.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        slctFuente.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        slctFuente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        slctRam.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        slctRam.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        slctHdd.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        slctHdd.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        slctGab.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        slctGab.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        slctCooler.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        slctCooler.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        tablaStock.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "idStock", "Producto", "Precio", "idTipo"
            }
        ));
        jScrollPane1.setViewportView(tablaStock);

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel10.setText("$");

        btnContinuar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnContinuar.setText("Continuar");
        btnContinuar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnContinuarActionPerformed(evt);
            }
        });

        btnVolver.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnVolver.setText("Volver al inicio");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(144, 144, 144)
                        .addComponent(jLabel1)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 463, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnContinuar, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnVolver))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addGap(44, 44, 44)
                                        .addComponent(jLabel10)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addComponent(jLabel2)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(slctMicro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel5)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(slctRam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel4)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(slctFuente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel3)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(slctMother, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel6)
                                                .addComponent(jLabel7))
                                            .addGap(18, 18, 18)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(slctGab, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(slctHdd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(slctCooler, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(slctMicro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(slctMother, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(slctFuente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(slctRam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(slctHdd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel7))
                    .addComponent(slctGab, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(slctCooler, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel10)
                        .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnContinuar, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnVolver))
                .addGap(21, 21, 21)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnContinuarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnContinuarActionPerformed
        Comprar();
        this.setVisible(false);
        comprarPCfin c= new comprarPCfin();
        c.setVisible(true);
    }//GEN-LAST:event_btnContinuarActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        this.setVisible(false);
        ingresar c= new ingresar();
        c.setVisible(true);
    }//GEN-LAST:event_btnVolverActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(comprarPC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(comprarPC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(comprarPC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(comprarPC.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new comprarPC().setVisible(true);
            }
        });
    }
    
    void listar() {
        String sql = "select * from stock";
        try {
            con = cn.getConnection();
            st = con.createStatement();
            rs = st.executeQuery(sql);
            Object[] productoStock = new Object[4];  
            model = (DefaultTableModel) tablaStock.getModel();
            while (rs.next()) {
                productoStock[0] = rs.getInt("idStock");
                productoStock[1] = rs.getString("nombreStock");
                productoStock[2] = rs.getDouble("precio");
                productoStock[3] = rs.getInt("idTipo");
                
                model.addRow(productoStock);
            }
            tablaStock.setModel(model);

        } catch (Exception e) {
        }

    }
    
    void Comprar() {
        
        int idMicro = Integer.parseInt((String) slctMicro.getSelectedItem());
        int idMother = Integer.parseInt((String) slctMother.getSelectedItem());
        int idFuente = Integer.parseInt((String) slctFuente.getSelectedItem());
        int idRam = Integer.parseInt((String) slctRam.getSelectedItem());
        int idDisco = Integer.parseInt((String) slctHdd.getSelectedItem());
        int idGab = Integer.parseInt((String) slctGab.getSelectedItem());
        int idCooler = Integer.parseInt((String) slctCooler.getSelectedItem());
        Double precio = Double.parseDouble((String) txtPrecio.getText());
        try {

                String sql = "insert into pcarmado(idArmado, precioTotal, idStockMicro, idStockMother, idStockFuente, idStockRam, idStockAlmacenamiento, idStockGabinete, idStockCooler) values( 0, " + precio + ", " + idMicro + ", " + idMother + ", " + idFuente + ", " + idRam + ", " + idDisco + ", "+ idGab+", "+ idCooler + ")";
                con = cn.getConnection();
                st = con.createStatement();
                st.executeUpdate(sql);
                JOptionPane.showMessageDialog(null, "Compra realizada con Exito");
            

        } catch (Exception e) {
        }
        
        
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnContinuar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> slctCooler;
    private javax.swing.JComboBox<String> slctFuente;
    private javax.swing.JComboBox<String> slctGab;
    private javax.swing.JComboBox<String> slctHdd;
    private javax.swing.JComboBox<String> slctMicro;
    private javax.swing.JComboBox<String> slctMother;
    private javax.swing.JComboBox<String> slctRam;
    private javax.swing.JTable tablaStock;
    private javax.swing.JTextField txtPrecio;
    // End of variables declaration//GEN-END:variables
}
